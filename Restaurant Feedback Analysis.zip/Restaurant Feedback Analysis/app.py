#############################
# Required Libraries Imported 
#############################

from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
import csv
import time
import pandas as pd
import json
from flask import Flask, render_template,request
import matplotlib.pyplot as plt

########################################################
# Initializing Flask and Loading Comments From JSON File
########################################################

app=Flask(__name__)

with open('processed_reviews.json') as file:
    comments=json.load(file)


######################################
# Rendering main page without comments
######################################

@app.route('/')
def dashboard():
    return render_template('dashboard.html',show_comments=False)


###################################
# Rendering main page with comments
###################################

@app.route('/comments')
def show_comments():
    return render_template('dashboard.html',show_comments=True,comments=comments)


######################################################
# Scrape function for initializing scraping operations 
######################################################


@app.route('/scrape', methods=['POST'])
def scrape():
    
    ############################################################ 
    # Get the competitor link from the form and creating its CSV
    ############################################################

    competitorLink=request.form['competitor_link']
    competitorCSV="competitor_reviews.csv"

    ################################################# 
    # Initializing driver and calling scrape function
    #################################################

    driver=webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))

    try:
        scrapeReviews(driver,competitorLink,competitorCSV,"Competitor Restaurant")

    except Exception as e:
        print("Error during scraping:",e)

    finally:
        driver.quit()

    ##################################
    # Calling plot after scraping ends
    ##################################

    try:
        plot()

    except Exception as e:
        print("Error during plotting:",e)

    return f"Scraping completed! Data saved to {competitorCSV}"


############################################
# Scraping reviews for competitor restaurant
############################################


def scrapeReviews(driver,url,csvFile,restaurantName):
    
    ################################
    # Opening CSV file in write mode
    ################################

    with open(csvFile,'w',newline='',encoding='utf-8') as csv_file:
        
        writer=csv.writer(csv_file)
        writer.writerow(["Restaurant Name","Review Content","Overall Rating","Date of Dining"])

        driver.get(url)
        time.sleep(3)
        
        while True:
            
            soup=BeautifulSoup(driver.page_source,"html.parser")
            
            ########################## 
            # Locating list of reviews
            ##########################

            reviewsList=soup.find("ol",id="restProfileReviewsContent")
            if(reviewsList):
                reviewItems=reviewsList.find_all("li",class_="afkKaa-4T28-") 
            else: 
                reviewItems=[]
            
            for review in reviewItems:
                try:

                    ###############################
                    # Extracting the review content
                    ###############################

                    content_tag=review.find("div", class_="_6rFG6U7PA6M-")
                    
                    if(content_tag):
                        content=content_tag.text.strip() 
                    
                    else: 
                        print("No Content")
                    
                    ###############################
                    # Extracting the overall rating
                    ###############################

                    overall_rating_tag=review.find("li", class_="-k5xpTfSXac-")
                    
                    if(overall_rating_tag):
                        overall_rating=overall_rating_tag.text.strip() 
                    
                    else: 
                        print("No Rating")
                    
                    ############################
                    # Extracting the review date
                    ############################

                    date_tag=review.find("p",class_="iLkEeQbexGs-")
                    
                    if(date_tag):
                        dining_date=date_tag.text.strip()
                    
                    else: 
                        print("No Date")
                    
                    ######################################
                    # Writing scraped data to the CSV file
                    ######################################

                    writer.writerow([restaurantName,content,overall_rating,dining_date])
                
                except Exception as e:
                    print("Error processing review:",e)
                    continue

                #####################
                # Moving to next page
                #####################
                
                try:
                    next_button=driver.find_element(By.CSS_SELECTOR, "a[aria-label='Go to the next page']")
                    next_button.click()
                
                except Exception as e:
                    print("No more pages to scrape or an error occurred:",e)
                    break

    driver.quit()
    print("Scraping completed! Data saved to ",{csvFile})


#####################################
# Extracting data of dining for plot
#####################################


def parse_date(date_str):
    try:

        if("Dined" in date_str and "days ago" in date_str):
            reference_date=pd.to_datetime("2024-12-11")
            days_ago=int(date_str.split()[1])

            return reference_date-pd.Timedelta(days=days_ago)

        elif("Dined on" in date_str):
            date_str=date_str.replace("Dined on","").strip()
            return pd.to_datetime(date_str,format='%B %d, %Y')

    except Exception as e:
        print("Error parsing date:",e)
        return pd.NaT
    
############################
# Plot function for plotting 
############################

def plot():

    ##################################
    # Reading CSVs and Extracting Data
    ##################################
    
    data1=pd.read_csv("copper_vine_reviews.csv")
    data2=pd.read_csv("competitor_reviews.csv")

    data1['Date of Dining']=data1['Date of Dining'].apply(parse_date)
    data2['Date of Dining']=data2['Date of Dining'].apply(parse_date)

    data1['Overall Rating']=data1['Overall Rating'].str.extract(r'(\d+)').astype(float)
    data2['Overall Rating']=data2['Overall Rating'].str.extract(r'(\d+)').astype(float)

    data1=data1.dropna(subset=['Date of Dining', 'Overall Rating'])
    data2=data2.dropna(subset=['Date of Dining', 'Overall Rating'])

    data1=data1.sort_values('Date of Dining')
    data2=data2.sort_values('Date of Dining')

    ########################## 
    # Plot Copper Vine Reviews
    ##########################

    plt.figure(figsize=(10, 6))
    plt.plot(data1['Date of Dining'], data1['Overall Rating'], label='Copper Vine Restaurant', marker='o', linestyle='-', color='blue')
    plt.title("Copper Vine Restaurant Ratings Over Time")
    plt.xlabel("Date of Dining")
    plt.ylabel("Overall Rating")
    plt.xticks(rotation=45)
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    #################################### 
    # Plot Competitor Restaurant Reviews
    ####################################

    plt.figure(figsize=(10, 6))
    plt.plot(data2['Date of Dining'], data2['Overall Rating'], label='Competitor Restaurant', marker='x', linestyle='-', color='red')
    plt.title("Competitor Restaurant Ratings Over Time")
    plt.xlabel("Date of Dining")
    plt.ylabel("Overall Rating")
    plt.xticks(rotation=45)
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    ############### 
    # Combined Plot
    ###############

    plt.figure(figsize=(10, 6))
    plt.plot(data1['Date of Dining'], data1['Overall Rating'], label='Copper Vine Restaurant', marker='o', linestyle='-', color='blue')
    plt.plot(data2['Date of Dining'], data2['Overall Rating'], label='Competitor Restaurant', marker='x', linestyle='-', color='red')
    plt.title("Overall Ratings Over Time")
    plt.xlabel("Date of Dining")
    plt.ylabel("Overall Rating")
    plt.legend()
    plt.xticks(rotation=45)
    plt.grid(True)
    plt.tight_layout()
    plt.show()

if(__name__=='__main__'):
    app.run(debug=True)



